{
    'name': 'Payment Add',
    'version': '17.0.0.1',
    'authors': 'swarup shah',
    'summary': 'Payment adding from custom',
    'description': 'payment adding',
    'sequence': -1,
    'category': 'Payment',
    'depends': ['base','payment','sale'],
    'data': [
        'data/payment_add.xml',

        'views/payment_provider.xml'
    ]
}