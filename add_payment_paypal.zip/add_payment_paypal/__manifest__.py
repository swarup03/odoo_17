{
    'name' : 'Payment Paypal',
    'version': '17.0.0.1',
    'author' : 'swarup shah',
    'summary': 'Payment adding from custom',
    'description': 'payment adding',
    'depends': ['base','sale','stock'],
    'license': 'OPL-1',
    'data': [
        'views/sale_payment_button.xml'
    ]
}