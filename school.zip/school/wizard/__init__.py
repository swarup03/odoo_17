from . import anotification_wizard
from . import total_amount_wizard
from . import cancel_student_wizard
from . import sale_report_wizard
from . import sale_delivery_wizard
from . import commission_sale_wizard