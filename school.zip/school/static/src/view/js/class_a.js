/* @odoo-module */
export class A {

    // methodA() {
    //     console.log("Method A from class A");
    // }
}