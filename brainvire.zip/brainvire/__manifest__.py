{
    'name' : 'Brainvire.infotech',
    'author' : 'swarup shah',
    'license': 'OPL-1',
}